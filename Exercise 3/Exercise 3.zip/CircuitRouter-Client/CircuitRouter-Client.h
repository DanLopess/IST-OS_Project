#ifndef CIRCUITROUTER_CLIENT_H
#define CIRCUITROUTER_CLIENT_H

#include "../lib/vector.h"
#include <sys/types.h>

void finishUp();

#endif /* CIRCUITROUTER_CLIENT_H */
