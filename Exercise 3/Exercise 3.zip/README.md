# Operating Systems Project

## Exercise 3
This exercise has an Advanced Shell and a Client program. Multiple clients can send commands to the 
shell, which will then execute the commands (through SeqSolver)

### Version 1.0
- Part 1 of the project is completed. All is working fine. 
- Multiple clients are able to talk to AdvShell without any problem

### Version 2.0
- Part 2 of the project is completed. All is working fine. 
- Multiple clients are able to talk to AdvShell without any problem and 
all signals run without problems. All verifications are done.

### Directories structure
`
EX2
├── Makefile
├── README.md
├── CircuitRouter-AdvShell
│	├── CircuitRouter-AdvShell.c
│	├── CircuitRouter-AdvShell.h
│	└── Makefile
├── CircuitRouter-Client
│	├── CircuitRouter-Client.c
│	├── CircuitRouter-Client.h
│	└── Makefile
├── CircuitRouter-SeqSolver
│	├── CircuitRouter-SeqSolver.c
│	├── coordinate.c
│	├── coordinate.h
│	├── grid.c
│	├── grid.h
│	├── Makefile
│	├── maze.c
│	├── maze.h
│	├── router.c
│	└── router.h
├── inputs
│	├── generate.py
│	├── random-x128-y128-z3-n128.txt
│	├── random-x128-y128-z3-n64.txt
│	├── random-x128-y128-z5-n128.txt
│	├── random-x256-y256-z3-n256.txt
│	├── random-x256-y256-z5-n256.txt
│	├── random-x512-y512-z7-n512.txt
│	├── random-x32-y32-z3-n64.txt
│	├── random-x32-y32-z3-n96.txt
│	├── random-x48-y48-z3-n48.txt
│	├── random-x48-y48-z3-n64.txt
│	├── random-x64-y64-z3-n48.txt
│	└── random-x64-y64-z3-n64.txt
├── lib
│	├── commandlinereader.c
│	├── commandlinereader.h
│	├── list.c
│	├── list.h
│	├── pair.c
│	├── pair.h
│	├── queue.c
│	├── queue.h
│	├── timer.h
│	├── types.h
│	├── utility.h
│	├── vector.c
│	└── vector.h
└──
`

### How to compile
`
- 1: open bash shell (terminal)
- 2: write cd Exercise 3 (root_directory path)
- 3: write "make"
- 4: Run AdvShell
		- write cd CircuitRouter-AdvShell
		- write "./CircuitRouter-AdvShell
		- write cd ..
- 5: Run clients (in another shell)
		- write cd CircuitRouter-Client
		- write "./CircuitRouter-Client /tmp/AdvShell.pipe"
		- write cd ..
- 6: go back to root_directory write "make clean"
- 6: close bash shell
`

### Testing
All testing was performed and executed in the machine whose specs are down below.
For assignment purposes, testing was also done in Sigma Environment (Lab's computers)

### Specs
- Operating System Information

Fedora 29 Workstation:

Linux Daniel-Fixo 4.18.16-300.fc29.x86_64 #1
SMP Sat Oct 20 23:24:08 UTC 2018 x86_64 x86_64 x86_64 GNU/Linux

- Hardware

Architecture:        x86_64
CPU op-mode(s):      32-bit, 64-bit
Byte Order:          Little Endian
CPU(s):              16
On-line CPU(s) list: 0-15
Thread(s) per core:  2
Core(s) per socket:  8
Socket(s):           1
Vendor ID:           AuthenticAMD
CPU family:          23
Model:               1
Model name:          AMD Ryzen 7 1700X Eight-Core Processor
CPU max MHz:         3850.0000
CPU min MHz:         2200.0000
Virtualization:      AMD-V
L1d cache:           32K
L1i cache:           64K
L2 cache:            512K
L3 cache:            8192K
NUMA node0 CPU(s):   0-15
